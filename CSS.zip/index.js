function set_Link (text) {
    document.getElementById("link").innerText=text;
}